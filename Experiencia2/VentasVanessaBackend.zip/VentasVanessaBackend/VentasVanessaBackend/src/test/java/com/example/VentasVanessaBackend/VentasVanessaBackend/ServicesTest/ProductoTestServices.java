package com.example.VentasVanessaBackend.VentasVanessaBackend.ServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Producto;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios.ProductoRepositorio;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Services.ProductoServicesImpl;

public class ProductoTestServices {

     @Mock
    private ProductoRepositorio productoRepository;

    @InjectMocks
    private ProductoServicesImpl productoServices;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testListarTodas() {
        when(productoRepository.findAll()).thenReturn(Arrays.asList(new Producto(), new Producto()));

        assertEquals(2, productoServices.listarTodas().size());
        verify(productoRepository).findAll();
    }

    @Test
    void testObtenerId() {
        Producto p = new Producto();
        p.setId(1L);

        when(productoRepository.findById(1L)).thenReturn(Optional.of(p));

        Producto result = productoServices.obtenerId(1L);
        assertNotNull(result);
        assertEquals(1L, result.getId());
    }

    @Test
    void testCrearProducto() {
        Producto p = new Producto();
        p.setNombre("Perfume");
        when(productoRepository.save(p)).thenReturn(p);

        Producto result = productoServices.crear(p);
        assertEquals("Perfume", result.getNombre());
    }

    @Test
    void testDesactivarProducto() {
        Producto p = new Producto();
        p.setId(1L);
        p.setActivo(true);

        when(productoRepository.findById(1L)).thenReturn(Optional.of(p));
        when(productoRepository.save(p)).thenReturn(p);

        Producto result = productoServices.desactivar(1L);

        assertFalse(result.getActivo());
        verify(productoRepository).save(p);
    }
}
