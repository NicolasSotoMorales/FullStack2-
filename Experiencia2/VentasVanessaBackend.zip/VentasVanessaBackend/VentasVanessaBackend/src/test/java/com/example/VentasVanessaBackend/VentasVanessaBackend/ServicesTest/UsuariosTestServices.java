package com.example.VentasVanessaBackend.VentasVanessaBackend.ServicesTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Usuario;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios.UsuarioRepositorio;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Services.UsuarioServicesImpl;

public class UsuariosTestServices {

    @Mock
    private UsuarioRepositorio usuarioRepository;

    @InjectMocks
    private UsuarioServicesImpl usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void saveTest() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Gabriel");
        usuario.setEmail("gabosilva12@gmail.com");

        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        Usuario res = usuarioService.crear(usuario);

        assertNotNull(res);
        assertEquals("Gabriel", res.getNombre());
        verify(usuarioRepository, times(1)).save(usuario);
    }

    @Test
    void findByIdFoundTest() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Maria");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        Usuario res = usuarioService.obtenerId(1L);

        assertNotNull(res);
        assertEquals(1L, res.getId());
        assertEquals("Maria", res.getNombre());
        verify(usuarioRepository, times(1)).findById(1L);
    }
    @Test
    void findByIdNotFoundTest() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> usuarioService.obtenerId(99L));
        verify(usuarioRepository, times(1)).findById(99L);
    }
}
