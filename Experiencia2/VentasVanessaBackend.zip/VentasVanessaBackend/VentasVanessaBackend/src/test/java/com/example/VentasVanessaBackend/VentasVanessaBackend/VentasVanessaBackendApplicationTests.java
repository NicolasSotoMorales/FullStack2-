package com.example.VentasVanessaBackend.VentasVanessaBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VentasVanessaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
