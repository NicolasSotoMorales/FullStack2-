package com.example.VentasVanessaBackend.VentasVanessaBackend.Services;

import java.util.List;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Categoria;

public interface CategoriaServices {

    Categoria crear(Categoria categoria);
    Categoria obtenerId(Long id);
    List<Categoria> listarTodas();    
    void eliminar(Long id);
    Categoria actualizar(Long id, Categoria categoriaActualizada);
}