package com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios;

import org.springframework.data.repository.CrudRepository;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Usuario;

public interface UsuarioRepositorio extends CrudRepository <Usuario, Long> {

}
