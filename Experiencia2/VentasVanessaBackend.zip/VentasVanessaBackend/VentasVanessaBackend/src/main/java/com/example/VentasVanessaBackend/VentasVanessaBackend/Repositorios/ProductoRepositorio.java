package com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios;

import org.springframework.data.repository.CrudRepository;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Producto;

public interface ProductoRepositorio extends CrudRepository <Producto, Long>{

}
