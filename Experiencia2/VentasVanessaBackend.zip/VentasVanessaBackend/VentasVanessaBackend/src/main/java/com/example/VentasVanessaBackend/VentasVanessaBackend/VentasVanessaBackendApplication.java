package com.example.VentasVanessaBackend.VentasVanessaBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentasVanessaBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentasVanessaBackendApplication.class, args);
	}

}
