package com.example.VentasVanessaBackend.VentasVanessaBackend.Services;

import java.util.List;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Usuario;
public interface UsuarioServices {
    Usuario crear(Usuario usuario);
    Usuario obtenerId(Long id);
    List<Usuario> listarTodas();    
    void eliminar(Long id);
    Usuario actualizar(Long id, Usuario usuarioActualizado);
}
