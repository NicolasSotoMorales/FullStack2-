package com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios;

import org.springframework.data.repository.CrudRepository;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Categoria;

public interface CategoriaRepositorio extends CrudRepository<Categoria, Long> {

}
