package com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Usuario {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String email;
    private String password;
    private String rol;

    //Metodo para designar rol
    public void asignarRol() {
        if (email != null && email.toLowerCase().endsWith("@ventasvanessa.com")) {
            this.rol = "ADMIN";
        } else {
            this.rol = "USER";
        }
    }

    
}
