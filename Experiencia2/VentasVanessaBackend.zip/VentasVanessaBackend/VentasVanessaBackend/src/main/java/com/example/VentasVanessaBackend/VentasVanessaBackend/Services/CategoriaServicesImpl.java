package com.example.VentasVanessaBackend.VentasVanessaBackend.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Categoria;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios.CategoriaRepositorio;

@Service
public class CategoriaServicesImpl implements CategoriaServices {
    @Autowired
    private CategoriaRepositorio categoriaRepositorio;
    
    @Override
    public Categoria crear(Categoria categoria) {
        return categoriaRepositorio.save(categoria);
    }

    @Override
    public Categoria obtenerId(Long id) {
        return categoriaRepositorio.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
    }

    @Override
    public List<Categoria> listarTodas() {
        return (List<Categoria>) categoriaRepositorio.findAll();
    }

    @Override
    public void eliminar(Long id) {
        if (!categoriaRepositorio.existsById(id)) {
            throw new RuntimeException("Categoría no encontrada");
        }
        categoriaRepositorio.deleteById(id);
    }

    @Override
    public Categoria actualizar(Long id, Categoria categoriaActualizada) {
        Categoria existente = obtenerId(id);
        existente.setNombre(categoriaActualizada.getNombre());
        return categoriaRepositorio.save(existente);
    }
}
