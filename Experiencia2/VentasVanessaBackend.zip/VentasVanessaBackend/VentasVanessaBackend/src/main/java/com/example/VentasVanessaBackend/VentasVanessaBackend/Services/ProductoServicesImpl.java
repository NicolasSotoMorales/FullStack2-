package com.example.VentasVanessaBackend.VentasVanessaBackend.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.VentasVanessaBackend.VentasVanessaBackend.Entidades.Producto;
import com.example.VentasVanessaBackend.VentasVanessaBackend.Repositorios.ProductoRepositorio;

@Service
public class ProductoServicesImpl implements ProductoServices {

    @Autowired
    private ProductoRepositorio productoRepositorio;

    @Override
    public Producto crear(Producto producto) {
        return productoRepositorio.save(producto);
    }

    @Override
    public Producto obtenerId(Long id) {
        return productoRepositorio.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
    }

    @Override
    public List<Producto> listarTodas() {
        return (List<Producto>) productoRepositorio.findAll();
    }

    @Override
    public void eliminar(Long id) {
        if (!productoRepositorio.existsById(id)) {
            throw new RuntimeException("Producto no encontrado");
        }
        productoRepositorio.deleteById(id);
    }

    @Override
    public Producto actualizar(Long id, Producto productoActualizado) {
        Producto existente = obtenerId(id);
        existente.setNombre(productoActualizado.getNombre());
        existente.setPrecio(productoActualizado.getPrecio());
        return productoRepositorio.save(existente);
    }

    @Override
    public Producto desactivar(Long id) {
        Producto existente = obtenerId(id);
        existente.setActivo(false);
        return productoRepositorio.save(existente);
    }
}
