import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Blog from "./pages/Blog";
import Contacto from "./pages/Contacto";
import Carrito from "./pages/Carrito";
import Login from "./pages/Login"; 
import DetallesProductos from './components/DetallesProductos';
import Admin from "./pages/admin.jsx";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/carrito" element={<Carrito />} />
        <Route path="/login" element={<Login />} /> 
        <Route path="/producto/:id" element={<DetallesProductos />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </Router>
  );
}

export default App;
