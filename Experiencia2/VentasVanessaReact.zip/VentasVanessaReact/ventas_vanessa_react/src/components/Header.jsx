import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import '../assets/css/EstilosPaginaPrincipal.css';

export default function Header() {
  const [nombreUsuario, setNombreUsuario] = useState("");

  useEffect(() => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario?.nombre) {
      setNombreUsuario(usuario.nombre);
    }
  }, []);

  return (
    <header>
      <Link className="logo" to="/">Ventas Vanessa</Link>
      <nav>
        <Link to="/">🏠Inicio</Link>
        <Link to="/blog">🗞️Blog</Link>
        <Link to="/contacto">📱Contacto</Link>
        <Link to="/carrito" className="cart-link">🛒 Carrito</Link>
        <Link to="/login" className="login-btn">👤Iniciar / Registrarse</Link>
        {nombreUsuario && (
          <span className="saludo-usuario">  Hola, {nombreUsuario} 👋</span>
        )}
      </nav>
    </header>
    )
}
