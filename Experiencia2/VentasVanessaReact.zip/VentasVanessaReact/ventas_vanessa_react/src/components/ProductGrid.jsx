import React from 'react';
import ProductCard from './ProductCard';

// ✅ Importar imágenes desde src/assets/img
import PoleraLaU from '../assets/img/PoleraLaU.jpg';
import Veston from '../assets/img/Veston.jpg';
import PoleraCelesteMangaCorta from '../assets/img/PoleraCelesteMangaCorta.jpg';
import PoleraNegraMangaLarga from '../assets/img/PoleraNegraMangaLarga.jpeg';
import PoleraMangaLargaBuho from '../assets/img/PoleraMangaLargaBuho.jpeg';
import PoleronGris from '../assets/img/PoleronGris.jpeg';
import PoleraMangaLargaCeleste from '../assets/img/PoleraMangaLargaCeleste.jpeg';
import PoleraLaUXXL from '../assets/img/PoleraLaUXXl.jpeg';
import PoleraConCuelloXXL from '../assets/img/PoleraConCuelloXXL.jpeg';
import PoleraRugbyXXL from '../assets/img/PoleraRugbyXXL.jpeg';

const products = [
  { href: '/producto/1', src: PoleraLaU, alt: 'Polera Club Universidad De Chile', title: 'Polera Universidad De Chile', price: '$25.000' },
  { href: '/producto/2', src: Veston, alt: 'Veston Mossimo', title: 'Veston Mossimo', price: '$35.000' },
  { href: '/producto/3', src: PoleraCelesteMangaCorta, alt: 'Polera Celeste Manga Corta', title: 'Polera Manga Corta', price: '$7.500' },
  { href: '/producto/4', src: PoleraNegraMangaLarga, alt: 'Polera Manga Larga Negra', title: 'Polera Manga Larga', price: '$21.000' },
  { href: '/producto/5', src: PoleraMangaLargaBuho, alt: 'Polera Manga Larga Buho', title: 'Polera Manga Larga Buho', price: '$35.000' },
  { href: '/producto/6', src: PoleronGris, alt: 'Poleron Gris', title: 'Poleron Gris', price: '$12.000' },
  { href: '/producto/7', src: PoleraMangaLargaCeleste, alt: 'Polera Manga Larga Celeste', title: 'Polera Manga Larga Celeste', price: '$15.000' },
  { href: '/producto/8', src: PoleraLaUXXL, alt: 'Polera La U XXL', title: '', price: '$9.990' },
  { href: '/producto/9', src: PoleraConCuelloXXL, alt: 'Polera Con Cuello XXL', title: '', price: '$35.000' },
  { href: '/producto/10', src: PoleraRugbyXXL, alt: 'Polera Rugby XXL', title: '', price: '$10.000' },
];

export default function ProductGrid() {
  return (
    <section className="products-section" id="products">
      <h2>Nuestra Selección</h2>
      <div className="products-grid">
        {products.map((p, i) => (
          <ProductCard key={i} {...p} />
        ))}
      </div>
    </section>
  );
}
