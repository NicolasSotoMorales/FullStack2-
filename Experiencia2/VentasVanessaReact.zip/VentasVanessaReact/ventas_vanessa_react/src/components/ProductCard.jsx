
export default function ProductCard({ href, src, alt, title, price }) {
  return (
    <div className="product-card">
      <a href={href}>
        <img alt={alt} src={src} />
      </a>
      <div className="product-info">
        <h3>{title}</h3>
        <p>{price}</p>
      </div>
    </div>
  );
}