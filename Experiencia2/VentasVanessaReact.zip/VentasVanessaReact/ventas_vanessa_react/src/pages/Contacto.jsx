
import React from 'react';
import Header from '../components/Header';
import '../assets/css/EstilosPaginaContacto.css';
import '../assets/css/EstilosPaginaPrincipal.css';

export default function Contacto() {
  return (
    <>
      <Header />
      <main>
        <div className="container">
          <div style={{ margin: '0 auto', maxWidth: '42rem', textAlign: 'center' }}>
            <h2 className="title">Ponte en Contacto</h2>
            <p className="subtitle">
              Estamos aquí para ayudarte. Contáctanos por correo electrónico o teléfono.
            </p>
          </div>

          <div className="contact-grid">
            <div className="contact-item">
              <div className="contact-icon-wrapper">
                <span className="material-symbols-outlined contact-icon"> Correo </span>
              </div>
              <h3 className="contact-title">Correo Electrónico</h3>
              <p className="contact-description">
                Nuestro equipo de soporte te responderá en 24 horas.
              </p>
              <a className="contact-link" href="mailto:ventasVanessa@gmail.com">
                ventasVanessa@gmail.com
              </a>
            </div>

            <div className="contact-item">
              <div className="contact-icon-wrapper">
                <span className="material-symbols-outlined contact-icon"> Llamar </span>
              </div>
              <h3 className="contact-title">Teléfono</h3>
              <p className="contact-description">
                Llámanos de Lunes a Viernes de 9am a 5pm.
              </p>
              <a className="contact-link" href="tel:+56956696435">
                +56 9 5669 6435
              </a>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
