import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import '../assets/css/EstilosPaginaPrincipal.css';

// Imágenes locales
import PoleraLaU from '../assets/img/PoleraLaU.jpg';
import Veston from '../assets/img/Veston.jpg';
import PoleraCelesteMangaCorta from '../assets/img/PoleraCelesteMangaCorta.jpg';
import PoleraNegraMangaLarga from '../assets/img/PoleraNegraMangaLarga.jpeg';
import PoleraMangaLargaBuho from '../assets/img/PoleraMangaLargaBuho.jpeg';
import PoleronGris from '../assets/img/PoleronGris.jpeg';
import PoleraMangaLargaCeleste from '../assets/img/PoleraMangaLargaCeleste.jpeg';
import PoleraLaUXXL from '../assets/img/PoleraLaUXXl.jpeg';
import PoleraConCuelloXXL from '../assets/img/PoleraConCuelloXXL.jpeg';
import PoleraRugbyXXL from '../assets/img/PoleraRugbyXXL.jpeg';

export default function Home() {
  const [productosAdmin, setProductosAdmin] = useState([]);

  const productosLocales = [
    { link: '/producto/1', image: PoleraLaU, title: 'Polera Universidad De Chile', price: '$25.000' },
    { link: '/producto/2', image: Veston, title: 'Veston Mossimo', price: '$35.000' },
    { link: '/producto/3', image: PoleraCelesteMangaCorta, title: 'Polera Manga Corta', price: '$7.500' },
    { link: '/producto/4', image: PoleraNegraMangaLarga, title: 'Polera Manga Larga', price: '$21.000' },
    { link: '/producto/5', image: PoleraMangaLargaBuho, title: 'Polera Manga Larga Buho', price: '$25.000' },
    { link: '/producto/6', image: PoleronGris, title: 'Polera Gris', price: '$15.000' },
    { link: '/producto/7', image: PoleraMangaLargaCeleste, title: 'Polera Manga Larga Celeste', price: '$20.000' },
    { link: '/producto/8', image: PoleraLaUXXL, title: 'Polera Universidad De Chile XXL', price: '$9.990' },
    { link: '/producto/9', image: PoleraConCuelloXXL, title: 'Polera con Cuello XXL', price: '$35.000' },
    { link: '/producto/10', image: PoleraRugbyXXL, title: 'Polera Rugby XXL', price: '$15.000' }
  ];

  useEffect(() => {
    const productosGuardados = JSON.parse(localStorage.getItem("productos")) || [];
    setProductosAdmin(productosGuardados);
  }, []);

  const todosLosProductos = [...productosLocales, ...productosAdmin];

  return (
    <>
      <Header />
      <main>
        <section className="hero">
          <h1>Ventas Vanessa</h1>
        </section>

        <section className="products-section" id="products">
          <h2>Nuestra Selección</h2>
          <div className="products-grid">
            {todosLosProductos.map((product, index) => (
              <div key={index} className="product-card">
                <a href={product.link || "#"}>
                  <img
                    src={product.image || product.imagen}
                    alt={product.title || product.nombre}
                  />
                </a>
                <div className="product-info">
                  <h3>{product.title || product.nombre}</h3>
                  <p>{product.price || `$${product.precio}`}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
