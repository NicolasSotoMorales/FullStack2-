import React from 'react';
import Header from '../components/Header';
import '../assets/css/EstiloBlogs.css';
import '../assets/css/EstilosPaginaPrincipal.css';


import PoleraLaU from '../assets/img/PoleraLaU.jpg';

export default function Blog() {
  const noticias = [
    {
      image: PoleraLaU,
      fecha: '15 de mayo de 2024',
      titulo: 'Tendencias de moda para el verano 2024',
      descripcion: 'Se agregó una nueva prenda a la tienda. ¡Es momento de conocerla!',
      link: '/producto/1',
      linkText: 'Ir a la prenda',
    },
    {
      image: null, 
      fecha: '10 de mayo de 2024',
      titulo: 'Cómo combinar accesorios para un look perfecto',
      descripcion: 'Aprende a combinar accesorios para crear looks impactantes. Desde joyas hasta bolsos...',
      link: '#',
      linkText: 'Leer más',
    },
    {
      image: null, 
      fecha: '5 de mayo de 2024',
      titulo: 'Guía de tallas: Encuentra tu ajuste ideal',
      descripcion: 'Nuestra guía de tallas te ayudará a encontrar el ajuste perfecto para cada prenda...',
      link: '#',
      linkText: 'Leer más',
    },
  ];

  return (
    <>
      <Header />
      <main style={{ flex: 1 }}> 
        <section className="noticias">
          <h2>Últimas Noticias y Actualizaciones</h2>
          <p className="descripcion">
            Mantente al día con las últimas noticias y tendencias de moda de Ventas Vanessa.
          </p>

          <div className="noticias-grid">
            {noticias.map((n, index) => (
              <article className="noticia-card" key={index}>
                {n.image && <img src={n.image} alt={n.titulo} />}
                <div className="contenido">
                  <span className="fecha">{n.fecha}</span>
                  <h3>{n.titulo}</h3>
                  <p>{n.descripcion}</p>
                  <a href={n.link} className="leer-mas">{n.linkText}</a>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
