
import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import '../assets/css/EstiloCarrito.css';
import '../assets/css/EstilosPaginaPrincipal.css';

export default function Carrito() {
  const [carrito, setCarrito] = useState([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('carrito')) || [];
    setCarrito(data);
  }, []);

  const eliminarProducto = (index) => {
    const newCart = [...carrito];
    newCart.splice(index, 1);
    setCarrito(newCart);
    localStorage.setItem('carrito', JSON.stringify(newCart));
  };

  const total = carrito.reduce((acc, item) => acc + item.precio, 0);

  return (
    <>
      <Header />
      <main className="cart-page" style={{ padding: '2rem' }}>
        <h1>Tu Carrito</h1>
        {carrito.length === 0 ? (
          <p>Tu carrito está vacío</p>
        ) : (
          carrito.map((item, index) => (
            <div key={index} className="cart-item">
              <img src={item.imagen} alt={item.nombre} />
              <strong>{item.nombre}</strong> - ${item.precio.toLocaleString('es-CL')}
              <button className="btn-eliminar" onClick={() => eliminarProducto(index)}>
                Eliminar
              </button>
            </div>
          ))
        )}
        {carrito.length > 0 && <h2>Total: ${total.toLocaleString('es-CL')}</h2>}
      </main>
    </>
  );
}
