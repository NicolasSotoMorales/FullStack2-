import React, { useState } from 'react';
import Header from '../components/Header';
import '../assets/css/EstilosPaginaPrincipal.css';

import PoleraLaU from '../assets/img/PoleraLaU.jpg';
import Veston from '../assets/img/Veston.jpg';
import PoleraCelesteMangaCorta from '../assets/img/PoleraCelesteMangaCorta.jpg';
import PoleronGris from '../assets/img/PoleronGris.jpeg';
import PoleraMangaLargaCeleste from '../assets/img/PoleraMangaLargaCeleste.jpeg';

export default function Home() {
  // Productos con categorías
  const products = [
    { id: 1, link: '/producto/1', image: PoleraLaU, title: 'Polera Universidad De Chile', price: '$25.000', category: 'Poleras' },
    { id: 2, link: '/producto/2', image: Veston, title: 'Veston Mossimo', price: '$35.000', category: 'Veston' },
    { id: 3, link: '/producto/3', image: PoleraCelesteMangaCorta, title: 'Polera Manga Corta', price: '$7.500', category: 'Poleras' },
    { id: 4, link: '/producto/4', image: PoleronGris, title: 'Poleron Gris', price: '$12.000', category: 'Polerones' },
    { id: 5, link: '/producto/5', image: PoleraMangaLargaCeleste, title: 'Polera Manga Larga Celeste', price: '$15.000', category: 'Poleras' },
  ];

  //  Estado del filtro
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  //  Filtrado dinámico
  const filteredProducts =
    selectedCategory === 'Todos'
      ? products
      : products.filter((p) => p.category === selectedCategory);

  // Categorías únicas
  const categories = ['Todos', ...new Set(products.map((p) => p.category))];

  return (
    <>
      <Header />

      <main>
        <section className="hero">
          <h1>Ventas Vanessa</h1>
        </section>

        {/* 🧭 Filtro de categorías */}
        <div className="category-filter">
          {categories.map((cat) => (
            <button
              key={cat}
              className={`filter-btn ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 🛍️ Grilla de productos */}
        <section className="products-section">
          <h2>Nuestra Selección</h2>
          <div className="products-grid">
            {filteredProducts.map((product) => (
              <div key={product.id} className="product-card">
                <a href={product.link}>
                  <img src={product.image} alt={product.title} />
                </a>
                <div className="product-info">
                  <h3>{product.title}</h3>
                  <p>{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
