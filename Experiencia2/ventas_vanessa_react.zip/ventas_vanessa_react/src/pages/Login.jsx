import React, { useState } from "react";
import "../assets/css/estiloLogin.css";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nombreRegistro, setNombreRegistro] = useState('');
  const [emailRegistro, setEmailRegistro] = useState('');
  const [passwordRegistro, setPasswordRegistro] = useState('');
  const navigate = useNavigate();

  const toggleForm = () => setIsLogin(!isLogin);

  const handleLogin = (e) => {
    e.preventDefault();

    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    const usuarioEncontrado = usuarios.find(
      (u) => u.email === email && u.password === password
    );

    if (!usuarioEncontrado) {
      alert("Correo o contraseña incorrectos");
      return;
    }

    localStorage.setItem("usuario", JSON.stringify({
      nombre: usuarioEncontrado.nombre,
      email: usuarioEncontrado.email
    }));

    if (email.includes("@VentasVanessa")) {
      navigate("/admin");
    } else {
      navigate("/");
    }

    window.location.reload();
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    const nuevoUsuario = {
      nombre: nombreRegistro,
      email: emailRegistro,
      password: passwordRegistro
    };

    try {
      const response = await fetch("http://localhost:8080/api/usuarios", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(nuevoUsuario)
      });

      if (response.ok) {
        const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
        usuarios.push(nuevoUsuario);
        localStorage.setItem("usuarios", JSON.stringify(usuarios));

        localStorage.setItem("usuario", JSON.stringify({
          nombre: nombreRegistro,
          email: emailRegistro
        }));

        alert("Usuario registrado correctamente");
        setIsLogin(true);
      } else {
        alert("Error al registrar usuario");
      }
    } catch (error) {
      console.error("Error en el registro:", error);
      alert("No se pudo conectar con el servidor");
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-wrapper">
        {/* Login */}
        <div className={`form-box login ${isLogin ? "visible" : "hidden"}`}>
          <h2>Login</h2>
          <form onSubmit={handleLogin}>
            <div className="input-box">
              <input
                type="email"
                placeholder="Ingresa tu correo"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="input-box">
              <input
                type="password"
                placeholder="Ingresa tu contraseña"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="options">
              <label><input type="checkbox" /> Recuérdame </label>
              <a href="#">¿Olvidaste tu contraseña?</a>
            </div>
            <button type="submit" className="btn">Iniciar sesión</button>
            <p className="switch">
              ¿No tienes una cuenta? <span onClick={toggleForm} className="toggle-link">Regístrate</span>
            </p>
          </form>
        </div>

        {/* Registro */}
        <div className={`form-box register ${isLogin ? "hidden" : "visible"}`}>
          <h2>Registro</h2>
          <form onSubmit={handleRegister}>
            <div className="input-box">
              <input
                type="text"
                placeholder="Ingresa tu nombre"
                required
                value={nombreRegistro}
                onChange={(e) => setNombreRegistro(e.target.value)}
              />
            </div>
            <div className="input-box">
              <input
                type="email"
                placeholder="Ingresa tu correo"
                required
                value={emailRegistro}
                onChange={(e) => setEmailRegistro(e.target.value)}
              />
            </div>
            <div className="input-box">
              <input
                type="password"
                placeholder="Crea una contraseña"
                required
                value={passwordRegistro}
                onChange={(e) => setPasswordRegistro(e.target.value)}
              />
            </div>
            <div className="input-box">
              <input
                type="password"
                placeholder="Confirma tu contraseña"
                required
              />
            </div>
            <label className="terms">
              <input type="checkbox" required /> Acepto los términos y condiciones
            </label>
            <button type="submit" className="btn">Registrarse</button>
            <p className="switch">
              ¿Ya tienes una cuenta? <span onClick={toggleForm} className="toggle-link">Ingresa ahora</span>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
