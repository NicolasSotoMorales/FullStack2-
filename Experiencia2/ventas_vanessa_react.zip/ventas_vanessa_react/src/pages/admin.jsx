import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import "../assets/css/EstilosPaginaPrincipal.css";

export default function Admin() {
  const [productos, setProductos] = useState([]);
  const [nombre, setNombre] = useState("");
  const [precio, setPrecio] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [imagen, setImagen] = useState(null);
  const [usuarios, setUsuarios] = useState([]);
  const navigate = useNavigate();

  // Protege el acceso y carga usuarios registrados
  useEffect(() => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (!usuario || !usuario.email.includes("@VentasVanessa")) {
      navigate("/");
    }

    const listaUsuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    setUsuarios(listaUsuarios);

    const productosGuardados = JSON.parse(localStorage.getItem("productos")) || [];
    setProductos(productosGuardados);
  }, []);

  // Maneja imagen como base64
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagen(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Agrega producto
  const handleSubmit = (e) => {
    e.preventDefault();
    const nuevoProducto = { nombre, precio, descripcion, imagen };
    const actualizados = [...productos, nuevoProducto];
    setProductos(actualizados);
    localStorage.setItem("productos", JSON.stringify(actualizados));
    setNombre("");
    setPrecio("");
    setDescripcion("");
    setImagen(null);
  };

  // Elimina producto
  const eliminarProducto = (index) => {
    const actualizados = productos.filter((_, i) => i !== index);
    setProductos(actualizados);
    localStorage.setItem("productos", JSON.stringify(actualizados));
  };

  return (
    <>
      <Header />

      <main className="contenedor">
        <h2>Panel de Administración</h2>

        {/* Formulario para agregar productos */}
        <section className="form-admin">
          <h3>Agregar Prenda</h3>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="Nombre de la prenda"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              required
            />
            <input
              type="number"
              placeholder="Precio"
              value={precio}
              onChange={(e) => setPrecio(e.target.value)}
              required
            />
            <textarea
              placeholder="Descripción"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              required
            ></textarea>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
            />
            <button type="submit">Agregar Prenda</button>
          </form>
        </section>

        {/* Lista de productos */}
        <section className="lista-productos">
          <h3>Lista de Productos</h3>
          {productos.length === 0 ? (
            <p>No hay productos agregados aún.</p>
          ) : (
            <table border="1" width="100%">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Precio</th>
                  <th>Descripción</th>
                  <th>Imagen</th>
                  <th>Acción</th>
                </tr>
              </thead>
              <tbody>
                {productos.map((producto, index) => (
                  <tr key={index}>
                    <td>{producto.nombre}</td>
                    <td>${producto.precio}</td>
                    <td>{producto.descripcion}</td>
                    <td>
                      {producto.imagen && (
                        <img src={producto.imagen} alt={producto.nombre} width="80" />
                      )}
                    </td>
                    <td>
                      <button onClick={() => eliminarProducto(index)}>Eliminar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        {/* Lista de usuarios registrados */}
        <section className="lista-usuarios">
          <h3>Usuarios Registrados</h3>
          {usuarios.length === 0 ? (
            <p>No hay usuarios registrados.</p>
          ) : (
            <table border="1" width="100%">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((usuario, index) => (
                  <tr key={index}>
                    <td>{usuario.nombre}</td>
                    <td>{usuario.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </>
  );
}
