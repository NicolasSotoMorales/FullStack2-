import React from 'react';
import { useParams } from 'react-router-dom';
import Header from './Header';
import '../assets/css/EstilosPaginaPrincipal.css';
import "../assets/css/EstiloProductos.css";

import PoleraLaU from '../assets/img/PoleraLaU.jpg';
import Veston from '../assets/img/Veston.jpg';
import PoleraCelesteMangaCorta from '../assets/img/PoleraCelesteMangaCorta.jpg';
import PoleraNegraMangaLarga from '../assets/img/PoleraNegraMangaLarga.jpeg';
import PoleraMangaLargaBuho from '../assets/img/PoleraMangaLargaBuho.jpeg';
import PoleronGris from '../assets/img/PoleronGris.jpeg';
import PoleraMangaLargaCeleste from '../assets/img/PoleraMangaLargaCeleste.jpeg';
import PoleraLaUXXL from '../assets/img/PoleraLaUXXl.jpeg';
import PoleraConCuelloXXL from '../assets/img/PoleraConCuelloXXL.jpeg';
import PoleraRugbyXXL from '../assets/img/PoleraRugbyXXL.jpeg';

const products = [
  { id: '1', image: PoleraLaU, title: 'Polera Universidad De Chile', price: '$25.000', description: 'Polera original del club Universidad de Chile N°10 jugador Montillo talla L.' },
  { id: '2', image: Veston, title: 'Veston Mossimo', price: '$35.000', description: 'Elegante vestón para todas tus ocasiones.' },
  { id: '3', image: PoleraCelesteMangaCorta, title: 'Polera Manga Corta', price: '$7.500', description: 'Polera cómoda de manga corta.' },
  { id: '4', image: PoleraNegraMangaLarga, title: 'Polera Manga Larga Negra', price: '$21.000', description: 'Polera de manga larga negra, estilo casual.' },
  { id: '5', image: PoleraMangaLargaBuho, title: 'Polera Manga Larga Búho', price: '$35.000', description: 'Polera con estampado de búho.' },
  { id: '6', image: PoleronGris, title: 'Polerón Gris', price: '$12.000', description: 'Polerón gris para días fríos.' },
  { id: '7', image: PoleraMangaLargaCeleste, title: 'Polera Manga Larga Celeste', price: '$15.000', description: 'Polera manga larga color celeste.' },
  { id: '8', image: PoleraLaUXXL, title: 'Polera Universidad De Chile XXL', price: '$9.990', description: 'Polera talla XXL de La U.' },
  { id: '9', image: PoleraConCuelloXXL, title: 'Polera con Cuello XXL', price: '$35.000', description: 'Polera con cuello XXL.' },
  { id: '10', image: PoleraRugbyXXL, title: 'Polera Rugby XXL', price: '$10.000', description: 'Polera de rugby XXL.' },
];
export default function DetallesProductos() {
  const { id } = useParams();
  const product = products.find(p => p.id === id);

  if (!product) return <p>Producto no encontrado.</p>;

  const agregarAlCarrito = () => {
    const carritoActual = JSON.parse(localStorage.getItem('carrito')) || [];
    const precioNumerico = parseInt(product.price.replace(/\$|\./g, ''));

    const productoParaGuardar = {
      nombre: product.title,
      imagen: product.image,
      precio: precioNumerico
    };

    carritoActual.push(productoParaGuardar);
    localStorage.setItem('carrito', JSON.stringify(carritoActual));
    alert('Producto agregado al carrito');
  };

  // 👇 Este return debe estar dentro de la función
  return (
    <>
      <Header />
      <main className="product-detail">
        <div className="product-detail-container">
          <img className="product-detail-image" src={product.image} alt={product.title} />
          <div className="product-detail-info">
            <h1>{product.title}</h1>
            <p className="price">{product.price}</p>
            <p className="description">{product.description}</p>
            <button className="cta-button" onClick={agregarAlCarrito}>
              Agregar al carrito
            </button>
          </div>
        </div>
      </main>
    </>
  );
}
