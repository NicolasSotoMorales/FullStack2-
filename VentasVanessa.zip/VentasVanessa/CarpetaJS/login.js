function getUsers() {
  return JSON.parse(localStorage.getItem("usuarios")) || [];
}

function saveUser(user) {
  const users = getUsers();
  users.push(user);
  localStorage.setItem("usuarios", JSON.stringify(users));
}

document.getElementById("register").addEventListener("submit", function(e) {
  e.preventDefault();

  const nombre = document.getElementById("nombre").value;
  const email = document.getElementById("register-email").value;
  const password = document.getElementById("register-password").value;
  const password2 = document.getElementById("register-password2").value;

  if(password !== password2) {
    alert("Las contraseñas no coinciden");
    return;
  }

  const nuevoUsuario = { nombre, email, password };
  saveUser(nuevoUsuario);

  localStorage.setItem("usuarioActivo", JSON.stringify(nuevoUsuario));
  alert("Registro exitoso, bienvenido " + nombre + "!");
  window.location.href = "PaginaPrincipal.html";
});

document.getElementById("login").addEventListener("submit", function(e) {
  e.preventDefault();

  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  const users = getUsers();
  const usuarioEncontrado = users.find(u => u.email === email && u.password === password);

  if (usuarioEncontrado) {
    localStorage.setItem("usuarioActivo", JSON.stringify(usuarioEncontrado));
    alert("Bienvenido de nuevo " + usuarioEncontrado.nombre + "!");

    if (email.includes("@VentasVanessa")) {
      window.location.href = "PaginaAdmin.html"; 
    } else {
      window.location.href = "PaginaPrincipal.html";
    }
  } else {
    alert("Correo o contraseña incorrectos");
  }
});
