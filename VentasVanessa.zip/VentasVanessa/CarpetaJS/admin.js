function obtenerProductos() {
  return JSON.parse(localStorage.getItem("productos")) || [];
}

function guardarProductos(productos) {
  localStorage.setItem("productos", JSON.stringify(productos));
}

function mostrarProductos() {
  const productos = obtenerProductos();
  const cuerpoTabla = document.querySelector("#tabla-productos tbody");
  cuerpoTabla.innerHTML = "";

  productos.forEach((p, index) => {
    const fila = document.createElement("tr");

    fila.innerHTML = `
      <td>${p.nombre}</td>
      <td><input type="number" value="${p.precio}" data-index="${index}" class="precio-input"></td>
      <td>${p.descripcion}</td>
      <td><button data-index="${index}" class="guardar-btn">Guardar</button></td>
    `;

    cuerpoTabla.appendChild(fila);
  });
}

document.getElementById("form-producto").addEventListener("submit", function(e) {
  e.preventDefault();

  const nombre = document.getElementById("nombre-prenda").value;
  const precio = parseFloat(document.getElementById("precio-prenda").value);
  const descripcion = document.getElementById("descripcion-prenda").value;

  const productos = obtenerProductos();
  productos.push({ nombre, precio, descripcion });
  guardarProductos(productos);

  this.reset();
  mostrarProductos();
});

document.querySelector("#tabla-productos").addEventListener("click", function(e) {
  if (e.target.classList.contains("guardar-btn")) {
    const index = e.target.dataset.index;
    const nuevoPrecio = parseFloat(document.querySelector(`.precio-input[data-index="${index}"]`).value);

    const productos = obtenerProductos();
    productos[index].precio = nuevoPrecio;
    guardarProductos(productos);

    alert("✅ Precio actualizado correctamente");
    mostrarProductos();
  }
});

mostrarProductos();