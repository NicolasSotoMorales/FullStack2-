function obtenerCarrito() {
  return JSON.parse(localStorage.getItem("carrito")) || [];
}
function guardarCarrito(carrito) {
  localStorage.setItem("carrito", JSON.stringify(carrito));
}
function agregarAlCarrito(producto) {
  let carrito = obtenerCarrito();
  carrito.push(producto);
  guardarCarrito(carrito);
  
}
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 1,
        nombre: "Polera Universidad De Chile",
        precio: 10000,
        imagen: "CarpetaImagenes/PoleraLaU.jpg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart2");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 2,
        nombre: "Veston mossimo",
        precio: 15000,
        imagen: "CarpetaImagenes/Veston.jpg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart3");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 3,
        nombre: "Polera Manga Corta",
        precio: 7500,
        imagen: "CarpetaImagenes/PoleraCelesteMangaCorta.jpg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart4");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 4,
        nombre: "Polera Manga Larga Negra",
        precio: 21000,
        imagen: "CarpetaImagenes/PoleraNegraMangaLarga.jpeg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart5");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 5,
        nombre: "Polera Manga Larga buho",
        precio: 10000,
        imagen: "CarpetaImagenes/PoleraMangaLargaBuho.jpeg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart6");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 6,
        nombre: "Poleron Gris",
        precio: 12000,
        imagen: "CarpetaImagenes/PoleronGris.jpeg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart7");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 7,
        nombre: "Polera Manga Larga Celeste",
        precio: 15000,
        imagen: "CarpetaImagenes/PoleraMangaLargaCeleste.jpeg"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart8");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 8,
        nombre: "",
        precio: 9990,
        imagen: "CarpetaImagenes/"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart9");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 9,
        nombre: "",
        precio: 35000,
        imagen: "CarpetaImagenes/"
      };
      agregarAlCarrito(producto);
    });
  }
});
document.addEventListener("DOMContentLoaded", () => {
  const boton = document.querySelector(".add-to-cart210");
  if (boton) {
    boton.addEventListener("click", () => {
      const producto = {
        id: 10,
        nombre: "",
        precio: 10000,
        imagen: "CarpetaImagenes/"
      };
      agregarAlCarrito(producto);
    });
  }
});